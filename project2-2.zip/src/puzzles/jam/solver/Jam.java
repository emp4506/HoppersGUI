package puzzles.jam.solver;

import puzzles.common.solver.Configuration;
import puzzles.common.solver.Solver;
import puzzles.jam.model.JamConfig;

import java.io.IOException;
import java.util.Collection;


public class Jam {
    public static void main(String[] args) {
        if (args.length != 1) {
            System.out.println("Usage: java Jam filename");
            return;
        }
        Solver solver = new Solver();
        Collection<Configuration> path = null;
        try {
            JamConfig start = new JamConfig(args[0]);
            path = solver.solve(start, null);
            System.out.println(start);
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("Total Configs: " + solver.totalConfigs);
        System.out.println("Unique configs: " + solver.predecessors.size() + "\n");
        if (!path.isEmpty()) {
            int i = 0;
            for (Configuration config : path) {
                System.out.println("Step " + i + ": \n" + config);
                ++i;
            }
        } else {
            System.out.println("No Solution");
        }
    }
}