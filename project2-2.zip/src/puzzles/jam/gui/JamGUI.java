package puzzles.jam.gui;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import puzzles.common.Observer;
import puzzles.hoppers.model.HoppersModel;
import puzzles.jam.model.Car;
import puzzles.jam.model.JamModel;

import java.io.IOException;
import java.util.ArrayList;

import javafx.scene.paint.Color;


/**
 * This is the GUI class for the Jam game. This implements the GUI using the JamModel
 *
 * @author Adam Zick, acz1626
 */

public class JamGUI extends Application  implements Observer<JamModel, String> {
    /**
     * The resources directory is located directly underneath the gui package
     */
    private final static String RESOURCES_DIR = "resources/";


    private final static int BUTTON_FONT_SIZE = 20;
    private final static int ICON_SIZE = 75;

    Color[] colorArray = {

    Color.YELLOW,
    Color.YELLOWGREEN,
    Color.GOLD,
    Color.INDIGO,
    Color.GOLDENROD,
    Color.ORANGE,
    Color.BEIGE,
    Color.WHEAT,
    Color.AQUA,
    Color.DARKGRAY,
    Color.BLUE, //
    Color.SALMON,
    Color.DARKRED,
    Color.FUCHSIA,
    Color.GREEN,
    Color.HOTPINK,
    Color.NAVAJOWHITE,
    Color.KHAKI,
    Color.LAVENDER,
    Color.BLACK, //
    Color.FIREBRICK,
    Color.CHARTREUSE,
    Color.OLIVE,
    Color.BISQUE,
    Color.NAVY,
    Color.MINTCREAM

    };

    char[] alphabet = "QWERTYUIOPASDFGHJKLZXCVBNM".toCharArray();

    /**
     * The current model that the GUI is displaying.
     */
    private JamModel model;

    /**
     * The current name for the file of the model.
     */
    private String filename;

    /**
     * The main stage that the GUI uses.
     */
    private Stage stage;

    /**
     * The horizontal box used for displaying the helper buttons.
     */
    private HBox bottom;

    /**
     * The label at the top of the borderpane.
     */
    private HBox label;

    /**
     * The borderpane that holds the label, gridpane and horizontal box.
     */
    private BorderPane borderPane;

    /**
     * The borderpane that holds the label, gridpane and horizontal box.
     */
    private GridPane center;
    private GridPane top;


    /**
     * The gridpane that holds all of the buttons for the cars.
     */
    private GridPane gridPane;



    /**
     * Initializes the GUI by creating a new model with the appropriate file name and creating an observer for it.
     *
     * @throws IOException This is basically ignored because the filename is valid from the args of the main method.
     */
    public void init() throws IOException {
        filename = getParameters().getRaw().get(0);
        this.model = new JamModel(filename);
        model.addObserver(this);
    }


    /**
     * Makes the top section of the BorderPane.
     * @param top   the GridPane object that is meant to be the top section.
     */
    public void makeTop(GridPane top){


        top.getRowConstraints().add(new RowConstraints(30));

        for(int c = 0; c < 3; c++){

            top.getColumnConstraints().add(new ColumnConstraints((ICON_SIZE*model.getCurrentConfig().getCOLS())/3));

        }



        ColumnConstraints column = new ColumnConstraints();
        column.setPercentWidth(30);

        String[] locations = filename.split("/");

        top.add(new Label("Loaded: " + locations[2]), 1,0);

        top.setGridLinesVisible(false);

    }












    /**
     * Makes the center section of the BorderPane.
     * @param center   the GridPane object that is meant to be the center section.
     */
    public void makeCenter(GridPane center) {

        for(int r = 0; r < model.getCurrentConfig().getROWS(); r++){

            center.getRowConstraints().add(new RowConstraints(ICON_SIZE));

        }

        for(int c = 0; c < model.getCurrentConfig().getCOLS(); c++){

            center.getColumnConstraints().add(new ColumnConstraints(ICON_SIZE));

        }


        for(int r = 0; r < model.getCurrentConfig().getROWS(); r++){

            for(int c = 0; c < model.getCurrentConfig().getCOLS(); c++){


                Button car = new Button();
                car.setStyle(
                        "-fx-font-size: " + BUTTON_FONT_SIZE + ";" +
                                "-fx-background-color: " + Color.GRAY + ";" +
                                "-fx-font-weight: bold;");
                car.setText(" ");
                car.setMinSize(ICON_SIZE, ICON_SIZE);
                car.setMaxSize(ICON_SIZE, ICON_SIZE);

                center.add(car, c, r);

            }
        }


        ArrayList<Car> cars = model.getCurrentConfig().getCars();
        Car[][] board = model.getCurrentConfig().getGrid();

        for(int r = 0; r < model.getCurrentConfig().getROWS(); r++){

            for(int c = 0; c < model.getCurrentConfig().getCOLS(); c++){

                if(board[r][c] != null){
                    Car current = board[r][c];

                    Color carColor = null;

                    for(int color = 0; color < alphabet.length; color++){
                        if(current.getLetter() == String.valueOf(alphabet[color])){
                            carColor = colorArray[color];
                        }
                    }

                    Button car = new Button();
                    car.setStyle(
                            "-fx-font-size: " + BUTTON_FONT_SIZE + ";" +
                                    "-fx-background-color: " + carColor + ";" +
                                    "-fx-font-weight: bold;");
                    car.setText(current.getLetter());
                    car.setMinSize(ICON_SIZE, ICON_SIZE);
                    car.setMaxSize(ICON_SIZE, ICON_SIZE);

                    center.add(car, c, r);


                }
            }


        }


        center.setGridLinesVisible(true);



    }



    /**
     * Creates the initial view for the Jam game.
     *
     * @param stage The main stage that the Jam game is displayed on.
     */
    @Override
    public void start(Stage stage) throws Exception {


        borderPane = new BorderPane();
        top = new GridPane();
        center = new GridPane();

        makeCenter(center);
        makeTop(top);

        borderPane.setTop(top);
        borderPane.setCenter(center);



        /*
        Button button1 = new Button();
        button1.setStyle(
                "-fx-font-size: " + BUTTON_FONT_SIZE + ";" +
                "-fx-background-color: " + X_CAR_COLOR + ";" +
                "-fx-font-weight: bold;");
        button1.setText("X");
        button1.setMinSize(ICON_SIZE, ICON_SIZE);
        button1.setMaxSize(ICON_SIZE, ICON_SIZE);

         */
        Scene scene = new Scene(borderPane);



        stage.setScene(scene);
        stage.show();
    }

    @Override
    public void update(JamModel jamModel, String msg) {




    }

    /**
     * The main function that initiates the GUI.
     * @param args arguments that are passed to the GUI.
     */
    public static void main(String[] args) {
        Application.launch(args);
    }
}
