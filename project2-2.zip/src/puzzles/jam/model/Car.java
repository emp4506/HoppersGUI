package puzzles.jam.model;

import java.util.Arrays;
import java.util.Objects;

public class Car {

    private String letter;
    private int length;

    private int ROWS;
    private int COLS;


    private boolean[][] coords;
    private int[] info = new int[4];

    private int startR;
    private int startC;
    private int endR;
    private int endC;

    private String orient;

    public Car(String letter, int startR, int startC, int endR, int endC, int ROWS, int COLS){

        this.letter = letter;

        this.ROWS = ROWS;
        this.COLS = COLS;

        coords = new boolean[ROWS][COLS];


        // sets the length of the car/truck if the vehicle is horizontal
        if(startR == endR){
            if(startC < endC){
                length = endC - startC;


            }else{
                length = startC - endC;
            }

            orient = "H";

        }


        // sets the length of the car/truck if the vehicle is vertical
        if(startC == endC){
            if(startR < endR){
                length = endR - startR;

            }else{
                length = startR - endR;

            }

            orient = "V";

        }

        info[0] = startR;
        info[1] = startC;
        info[2] = endR;
        info[3] = endC;

        this.startR = startR;
        this.startC = startC;
        this.endR = endR;
        this.endC = endC;

        // fills coordinate grid
        for(int c = 0; c < COLS; c++){

            for(int r = 0; r < ROWS; r++){

                coords[r][c] = false;
            }

        }

        if(this.isVertical()){
            int currentR = startR;
            while(currentR != endR+1){
                coords[currentR][startC] = true;
                currentR += 1;
            }
        }
        if(this.isHorizontal()){
            int currentC = startC;
            while(currentC != endC+1){
                coords[startR][currentC] = true;
                currentC += 1;
            }
        }


    }


    //second constructor, so I can make the cars without coordinates for comparison purposes
    public Car (String letter){
        this.letter = letter;
    }





    /**
     * true if the car is vertically oriented
     * @return if the car is vertical
     */
    public boolean isVertical() {
        return Objects.equals(orient, "V");
    }

    /**
     * true if the car is horizontally oriented
     * @return if the car is horizontal
     */
    public boolean isHorizontal() {
        return Objects.equals(orient, "H");
    }

    /**
     * get method for the orientation
     * @return the orientation
     */
    public String getOrient() {
        return orient;
    }

    /**
     * get method for the info array that holds
     * the identifying letter, start and end coords,
     * etc.
     * @return the info array
     */
    public int[] getInfo(boolean print){

        if(print){
            System.out.println("Start Row: " + info[0]);
            System.out.println("End Row: " + info[1]);
            System.out.println("Start Column: " + info[2]);
            System.out.println("End Column: " + info[3]);
            return info;
        }else{
            return info;
        }


    }

    //-=-=-=-=-=-=-=-=-=--=-=--=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-//
    //getters and setters for the start and end coordinates
    //
    public int getEndC() {
        return endC;
    }

    public void setEndC(int endC) {
        this.endC = endC;
    }

    public int getEndR() {
        return endR;
    }

    public void setEndR(int endR) {
        this.endR = endR;
    }

    public int getStartC() {
        return startC;
    }

    public void setStartC(int startC) {
        this.startC = startC;
    }

    public int getStartR() {
        return startR;
    }

    public void setStartR(int startR) {
        this.startR = startR;
    }

    //-=-=-=-=-=-=-=-=-=--=-=--=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-//
    // methods to easily move the car coords up, down, left, right
    //
    public void moveLeft(){
        this.startC -= 1;
        this.endC -= 1;

        // fills coordinate grid
        for(int c = 0; c < COLS; c++){

            for(int r = 0; r < ROWS; r++){

                coords[r][c] = false;
            }

        }

        if(this.isHorizontal()){
            int currentC = startC;
            while(currentC <= endC){
                coords[startR][currentC] = true;
                currentC += 1;
            }
        }
    }

    public void moveRight(){
        this.startC += 1;
        this.endC += 1;

        // fills coordinate grid
        for(int c = 0; c < COLS; c++){

            for(int r = 0; r < ROWS; r++){

                coords[r][c] = false;
            }

        }

        if(this.isHorizontal()){
            int currentC = startC;
            while(currentC <= endC){
                coords[startR][currentC] = true;
                currentC += 1;
            }
        }




    }

    public void moveUp(){
        this.startR -= 1;
        this.endR -= 1;

        // fills coordinate grid
        for(int c = 0; c < COLS; c++){

            for(int r = 0; r < ROWS; r++){

                coords[r][c] = false;
            }

        }

        if(this.isVertical()){
            int currentR = startR;
            while(currentR <= endR){
                coords[currentR][startC] = true;
                currentR += 1;
            }
        }



    }

    public void moveDown(){
        this.startR += 1;
        this.endR += 1;



        // fills coordinate grid
        for(int c = 0; c < COLS; c++){

            for(int r = 0; r < ROWS; r++){

                coords[r][c] = false;
            }

        }

        if(this.isVertical()){
            int currentR = startR;
            while(currentR <= endR){
                coords[currentR][startC] = true;
                currentR += 1;
            }
        }

    }

    //-=-=-=-=-=-=-=-=-=--=-=--=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-//



    public int getLength(){
        return length;
    }

    public boolean[][] getCoords(){
        return coords;
    }

    public boolean occupies(int row, int col){
        if(coords[row][col]){
            return true;
        }else{
            return false;
        }
    }

    public void refresh(){

        // fills coordinate grid
        for(int c = 0; c < COLS; c++){

            for(int r = 0; r < ROWS; r++){

                coords[r][c] = false;
            }

        }

        if(this.isVertical()){
            int currentR = startR;
            while(currentR != endR+1){
                coords[currentR][startC] = true;
                currentR += 1;
            }
        }
        if(this.isHorizontal()){
            int currentC = startC;
            while(currentC != endC+1){
                coords[startR][currentC] = true;
                currentC += 1;
            }
        }
    }


    public String getLetter() {
        return letter;
    }


    public void set(int[] info) {
        this.info = info;
    }

    @Override
    public String toString() {
        return "Car{" + "letter='" + letter + '\'' + startC + " " + endC+'}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Car car = (Car) o;
        return length == car.length && startR == car.startR && startC == car.startC && endR == car.endR && endC == car.endC && Objects.equals(letter, car.letter)  && Objects.equals(orient, car.orient) && Arrays.deepEquals(coords, car.coords) && Arrays.equals(info, car.info);
    }

    @Override
    public int hashCode() {
        int result = Objects.hash(length, startR, startC, endR, endC, letter, orient);
        result = (31 * result) + Arrays.deepHashCode(coords);
        result = 31 * result + Arrays.hashCode(info);
        return result;
    }
}
