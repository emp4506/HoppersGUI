package puzzles.jam.model;

import puzzles.common.solver.Configuration;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Objects;

/**
 * This is the Jam Config that the common solver will use.
 *
 * @author Adam Zick, acz1626
 */

public class JamConfig implements Configuration {

    /**
     * a cell that has not been assigned a value yet
     */
    private final static char EMPTY = '.';

    /**
     * The number of rows of the grid.
     */
    private int ROWS;

    /**
     * The number of columns of the grid.
     */
    private int COLS;

    /**
     * The number of Cars of the grid.
     */
    private int NUM_CARS;

    /**
     * The grid which stores the location of each car and the available/unavailable spaces it can go to.
     */
    private Car[][] grid;

    /**
     * An arraylist of all cars.
     */
    private ArrayList<Car> cars = new ArrayList<>();

    /**
     * Creates the configuration that reads the file and creates the jam grid.
     *
     * @param filename The file name.
     * @throws IOException Not needed because the file passed in is valid. (Needs it for compiling)
     */
    public JamConfig(String filename) throws IOException {
        try (BufferedReader in = new BufferedReader(new FileReader(filename))) {


            // read first line: rows cols
            String[] fields = in.readLine().split("\\s+");


            ROWS = Integer.parseInt(fields[0]);
            COLS = Integer.parseInt(fields[1]);

            //-- grid building --//
            grid = new Car[ROWS][COLS];


            fields = in.readLine().split("\\s+");
            NUM_CARS = Integer.parseInt(fields[0]);


            //-- fills the arraylist with car objects --//
            for (int i = 0; i < NUM_CARS; i++) {

                fields = in.readLine().split("\\s+");

                cars.add(new Car(fields[0], Integer.parseInt(fields[1]), Integer.parseInt(fields[2]), Integer.parseInt(fields[3]), Integer.parseInt(fields[4]), this.ROWS, this.COLS));

            }


            //-- puts the car objects in the grid --//
            for (int i = 0; i < NUM_CARS; i++) {

                Car current = cars.get(i);

                // System.out.println(current);
                //loops and puts the current car in the correct pos. based on occupies()
                for (int r = 0; r < ROWS; r++) {

                    for (int c = 0; c < COLS; c++) {

                        if (current.occupies(r, c)) {
                            grid[r][c] = current;
                        }

                    }
                }
            }


        }


    }


    /**
     * The copy constructor that the getneighbors function uses to create the neighbors of a given car.
     * @param other     the previous configuration.
     * @param letter    the letter of the car that is modified inside the constructor.
     * @param direction the direction for the car to move in.
     */
    public JamConfig(JamConfig other, String letter, String direction) {


        this.ROWS = other.ROWS;
        this.COLS = other.COLS;

        Car current = null;

        //-- grid building --//
        this.grid = new Car[ROWS][COLS];

        this.NUM_CARS = other.NUM_CARS;

        cars = new ArrayList<Car>();

        for (Car car : other.cars) {

            if (car.getLetter().equals(letter)) {
                current = car;
            } else {
                this.cars.add(car);
            }

        }

        int oldStartR = current.getStartR();
        int oldEndR = current.getEndR();
        int oldStartC = current.getStartC();
        int oldEndC = current.getEndC();

        if (direction.equals("left")) {

            Car newCar = new Car(current.getLetter(), oldStartR, oldStartC - 1, oldEndR, oldEndC - 1, ROWS, COLS);
            cars.add(newCar);

        } else if (direction.equals("right")) {

            Car newCar = new Car(current.getLetter(), oldStartR, oldStartC + 1, oldEndR, oldEndC + 1, ROWS, COLS);
            cars.add(newCar);

        } else if (direction.equals("up")) {

            Car newCar = new Car(current.getLetter(), oldStartR - 1, oldStartC, oldEndR - 1, oldEndC, ROWS, COLS);
            cars.add(newCar);

        } else if (direction.equals("down")) {

            Car newCar = new Car(current.getLetter(), oldStartR + 1, oldStartC, oldEndR + 1, oldEndC, ROWS, COLS);
            cars.add(newCar);

        }


        //-- puts the car objects in the grid --//
        for (int i = 0; i < NUM_CARS; i++) {

            Car currently = cars.get(i);
            //currently.refresh();


            //loops and puts the current car in the correct pos. based on occupies()
            for (int r = 0; r < ROWS; r++) {

                for (int c = 0; c < COLS; c++) {

                    if (currently.occupies(r, c)) {
                        this.grid[r][c] = currently;

                    }
                }
            }
        }


    }

    /**
     * Tests if the local configuration is the solution.
     * @return  boolean: True if the configuration is the solution, false if it isn't.
     */
    @Override
    public boolean isSolution() {

        //Car target = new Car("X");

        for (int i = 0; i < cars.size(); i++) {

            if (cars.get(i).getLetter().equals("X") && cars.get(i).getEndC() == COLS - 1) {
                return true;
            }

        }
        return false;
    }


    /**
     * Tests if the coordinate that is passed is occupied by a car.
     * @param row   Row of the coordinates to be tested.
     * @param col   Column of the coordinates to be tested.
     * @return  boolean: True if the coordinates are empty, false if they aren't.
     */
    public boolean notOccupied(int row, int col) {

        return grid[row][col] == null;

    }


    /**
     * Gets the neighbors of the local configuration.
     * @return  The collection of neighbors of the given configuration.
     */
    @Override
    public Collection<Configuration> getNeighbors() {

        ArrayList<Configuration> configs = new ArrayList<Configuration>();

        for (int i = 0; i < cars.size(); i++) {

            Car current = cars.get(i);


            // if the car is horizontal, see if it can move left or right and add a config if it can
            if (current.isHorizontal()) {
                if (current.getStartC() != 0 && notOccupied(current.getStartR(), current.getStartC() - 1)) {

                    configs.add(new JamConfig(this, current.getLetter(), "left"));
                }


                if (!(current.getEndC() >= COLS - 1) && notOccupied(current.getEndR(), current.getEndC() + 1)) {

                    configs.add(new JamConfig(this, current.getLetter(), "right"));
                }


            }

            // if the car is horizontal, see if it can move left or right and add a config if it can
            if (current.isVertical()) {
                if (current.getStartR() != 0 && notOccupied(current.getStartR() - 1, current.getStartC())) {

                    configs.add(new JamConfig(this, current.getLetter(), "up"));
                }

                if (!(current.getEndR() >= ROWS - 1) && notOccupied(current.getEndR() + 1, current.getStartC())) {

                    configs.add(new JamConfig(this, current.getLetter(), "down"));
                }


            }


        }//for loop

        return configs;

    }//get Neighbors


    /**
     * Checks if two configurations are equal.
     * @param o The other configuration.
     * @return  boolean: True if the configurations are equal, false if they aren't.
     */
    @Override
    public boolean equals(Object o) {

        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        JamConfig jamConfig = (JamConfig) o;

        return Arrays.deepEquals(grid, jamConfig.grid);
    }

    /**
     * Hashes the current configuration.
     * @return  The hash of the configuration's grid.
     */
    @Override
    public int hashCode() {

        return Arrays.deepHashCode(grid);

    }

    /**
     * Gets the grid's columns.
     * @return The grid's columns.
     */
    public int getCOLS() {
        return COLS;
    }

    /**
     * Gets the grid's rows.
     * @return The grid's rows.
     */
    public int getROWS() {
        return ROWS;
    }

    /**
     * Gets the grid.
     * @return The grid.
     */
    public Car[][] getGrid() {
        return grid;
    }

    /**
     * Gets the local configuration's cars Arraylist.
     * @return The local configuration's cars Arraylist.
     */
    public ArrayList<Car> getCars() {
        return cars;
    }


    /**
     * Creates a string representation of the configuration.
     *
     * @return The string representation of the configuration.
     */
    @Override
    public String toString() {

        // StringBuilder result = new StringBuilder();
        String result = "";
        int counter = 0;

        for (int r = 0; r < ROWS; r++) {

            for (int c = 0; c < COLS; c++) {

                if (grid[r][c] != null) {
                    result = result + " " + grid[r][c].getLetter() + " ";
                    counter++;
                } else {
                    result = result + " . ";
                    counter++;
                }


            }

            result += "\n";
        }


        // return result.toString();
        return result;

    }
}//class
