package puzzles.jam.model;

import puzzles.common.Observer;
import puzzles.common.solver.Configuration;
import puzzles.common.solver.Solver;
import puzzles.hoppers.model.HoppersConfig;

import java.io.File;
import java.io.IOException;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

/**
 * This is the Jam model that does the logic for the Jam GUI
 *
 * @author Adam Zick, acz1626
 */
public class JamModel {

    /** the collection of observers of this model */
    private final List<Observer<JamModel, String>> observers = new LinkedList<>();

    /** the current configuration */
    private JamConfig currentConfig;

    /**
     * A value to use to determine if the user has selected a car.
     */
    private boolean selection;

    /**
     * The selected row.
     */
    private int selR;

    /**
     * THe selected column.
     */
    private int selC;

    /**
     * creates the model and configuration using the filename, also initializes the selection boolean.
     *
     * @param filename The current name for the file of the model.
     * @throws IOException Needed for compiling.
     */
    public JamModel(String filename) throws IOException {
        currentConfig = new JamConfig(filename);
        selection = false;
    }




    /**
     * The view calls this to add itself as an observer.
     *
     * @param observer the view
     */
    public void addObserver(Observer<JamModel, String> observer) {
        this.observers.add(observer);
    }

    /**
     * The model's state has changed (the counter), so inform the view via
     * the update method.
     */
    private void alertObservers(String msg) {
        for (var observer : observers) {
            observer.update(this, msg);
        }
    }

    /**
     * Gives the user a hint using the solver and the second output that is in the path.
     * If there is no solution, notify the user that there is no solution.
     */
    public void hint(){

        Solver solver = new Solver();
        Collection<Configuration> path = solver.solve(currentConfig, null);
        JamConfig hintConfig;
        boolean solved = false;
        int i = 0;
        if (!path.isEmpty()) {
            if (path.size() == 1) {
                System.out.println("Already solved!");
                solved = true;
            } else {
                for (Configuration config : path) {
                    if (i == 1) {
                        hintConfig = (JamConfig) config;
                        this.currentConfig = hintConfig;
                        break;
                    }
                    ++i;
                }
                System.out.println("Next step!");
            }
            if (solved) {
                alertObservers("Already solved!");
            } else {
                alertObservers("Next step!");
            }
        } else {
            System.out.println("There is no solution :(");
            alertObservers("There is no solution :(");
        }





    }


    /**
     * Loads a new game if the file name is valid for Jam.
     * If the filename is invalid, notify the user.
     * @param filename The file name.
     */
    public void load(String filename) {

        try {
            this.currentConfig = new JamConfig(filename);
            selection = false;
            filename = filename.substring(filename.lastIndexOf(File.separator) + 1);
            System.out.println("Loaded: " + filename);
            alertObservers("Loaded: " + filename);
        } catch (IOException e) {
            System.out.println("Failed to load: " + filename);
            alertObservers("Failed to load: " + filename);
        }



    }

    /**
     * Gets the model's current configuration.
     * @return  The model's current configuration.
     */
    public JamConfig getCurrentConfig() {
        return currentConfig;
    }

    /**
     * For the first selection, the user is able to select a coordinate on the board. If there is a car there, there is an
     * indication and the selection advances to the second part. The user then selects an empty space in the correct direction,
     * and one cell away from the car in said direction. The car then shifts coordinates in that direction.
     * Otherwise if there is no car there an error message displayed and selection ends.
     * @param r The row of the selection.
     * @param c The column of the selection.
     */
    public void select(int r, int c) {
        // System.out.println("Select hasn't been completed yet :(");

        boolean space = currentConfig.notOccupied(r, c);
        Car[][] board = currentConfig.getGrid();

        if(!selection){

            if(r < currentConfig.getROWS() && c < currentConfig.getCOLS() && r >= 0 && c >= 0 && board[r][c] != null){

                selR = r;
                selC = c;
                selection = true;

                System.out.println("Selected (" + r + ", " + c + ")");
                alertObservers("Selected (" + r + ", " + c + ")");


            }else{

                System.out.println("Invalid selection (" + r + ", " + c + ")");
                alertObservers("Invalid selection (" + r + ", " + c + ")");

            }



        }else{

            boolean works = currentConfig.notOccupied(r, c);
            Car selected = new Car(board[selR][selC].getLetter(), board[selR][selC].getStartR(), board[selR][selC].getStartC(), board[selR][selC].getEndR(), board[selR][selC].getEndC(), currentConfig.getROWS(), currentConfig.getCOLS());


            if(works){

                if(selected.getOrient().equals("H") && r == selected.getStartR()
                        && (c-1 == selected.getEndC() || c+1 == selected.getStartC())){

                    if(c-1 == selected.getEndC()){

                        currentConfig = new JamConfig(currentConfig, selected.getLetter(), "right");

                        System.out.println("Drove from (" + selR + ", " + selC + ")  to (" + r + ", " + c + ")");
                        alertObservers("Drove from (" + selR + ", " + selC + ")  to (" + r + ", " + c + ")");

                    }
                    if(c+1 == selected.getStartC()){

                        currentConfig = new JamConfig(currentConfig, selected.getLetter(), "left");

                        System.out.println("Drove from (" + selR + ", " + selC + ")  to (" + r + ", " + c + ")");
                        alertObservers("Drove from (" + selR + ", " + selR + ")  to (" + r + ", " + c + ")");

                    }





                }else if(selected.getOrient().equals("V") && c == selected.getStartC()
                        && (r-1 == selected.getEndR() || r+1 == selected.getStartR())){

                    if(r-1 == selected.getEndR()){

                        currentConfig = new JamConfig(currentConfig, selected.getLetter(), "down");

                        System.out.println("Drove from (" + selR + ", " + selC + ")  to (" + r + ", " + c + ")");
                        alertObservers("Drove from (" + selR + ", " + selC + ")  to (" + r + ", " + c + ")");

                    }
                    if(r+1 == selected.getStartR()){

                        currentConfig = new JamConfig(currentConfig, selected.getLetter(), "up");

                        System.out.println("Drove from (" + selR + ", " + selC + ")  to (" + r + ", " + c + ")");
                        alertObservers("Drove from (" + selR + ", " + selR + ")  to (" + r + ", " + c + ")");

                    }
                }else{

                    System.out.println("Can't drive from (" + selR + ", " + selC + ")  to (" + r + ", " + c + ")");
                    alertObservers("Can't drive from (" + selR + ", " + selC + ")  to (" + r + ", " + c + ")");
                    selection = false;

                }




            }


            selection = false;

        }






    }


    /**
     * Resets the board to the initial state.
     *
     * @param filename The file name of the current board.
     */
    public void reset(String filename) {
        try {
            this.currentConfig = new JamConfig(filename);
            selection = false;
            System.out.println("Puzzle Reset!");
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            alertObservers("Puzzle Reset!");
        }
    }


    /**
     * Displays a string representation of the current configuration.
     * @return  The string representation of the current configuration.
     */
    @Override
    public String toString() {

        // StringBuilder result = new StringBuilder();
        String result = "";
        int counter = 0;
        Car[][] confGrid = currentConfig.getGrid();

        for (int r = 0; r < currentConfig.getROWS(); r++) {

            for (int c = 0; c < currentConfig.getCOLS(); c++) {

                if (confGrid[r][c] != null) {
                    result = result + " " + confGrid[r][c].getLetter() + " ";
                    counter++;
                } else {
                    result = result + " . ";
                    counter++;
                }


            }

            result += "\n";
        }


        // return result.toString();
        return result;

    }

}
